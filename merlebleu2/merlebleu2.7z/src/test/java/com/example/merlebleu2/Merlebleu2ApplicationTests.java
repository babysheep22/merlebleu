package com.example.merlebleu2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Merlebleu2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
