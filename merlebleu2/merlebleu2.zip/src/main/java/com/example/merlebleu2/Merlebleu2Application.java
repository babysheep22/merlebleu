package com.example.merlebleu2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Merlebleu2Application {

	public static void main(String[] args) {
		SpringApplication.run(Merlebleu2Application.class, args);
	}

}
