package com.example.merlebleu2.constant;

public enum Role {
    USER, ADMIN
}
